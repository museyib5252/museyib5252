<!DOCTYPE html>

<html>

<head>

<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

body {

  font-family: Arial, Helvetica, sans-serif;

  background-color: #FFFFFF;

}



* {

  box-sizing: border-box;

}



/* Add padding to containers */

.container {

  padding: 16px;

  background-color: white;

}



/* Full-width input fields */

input[type=text], input[type=Password] {

  width: 100%;

  padding: 15px;

  margin: 5px 0 22px 0;

  display: inline-block;

  border: none;

  background: #f1f1f1;

}



input[type=text]:focus, input[type=Password]:focus {

  background-color: #ddd;

  outline: none;

}



/* Overwrite default styles of hr */

hr {

  border: 1px solid #f1f1f1;

  margin-bottom: 25px;

}



/* Set a style for the submit button */

.button1 {

  background-color: #0091EA;

  color: white;

  padding: 16px 20px;

  margin: 8px 0;

  border: none;

  cursor: pointer;

  width: 100%;

  opacity: 0.9;

}



.registerbtn:hover {

  opacity: 1;

}



/* Add a blue text color to links */

a {

  color: dodgerblue;

}



/* Set a grey background color and center the text of the "sign in" section */

.signin {

  background-color: #f1f1f1;

  text-align: center;

}

</style>

</head>

<body>

 <div class="container">

    <center>

    <h2>LieShooter</h2>

    <p>Get Key Page</p>

    </center>

    <hr>



    <label for="SelectInfo"><b>Select one</b></label>
    
    <button type="submit" class="button1" onclick="window.location.href='https://duit.cc/7sQ4'">Get Free Key</button>
    <button type="submit" class="button1" onclick="window.location.href='https://t.me/LieShooter_TG'">Get Paid Key</button>
    <br>

    <br>

    <br>

  </div>



</body>

</html>

